#!/usr/bin/env python3
"""Store the Anthropic API key in the login keychain, where image-subject.py reads it.

    /usr/bin/python3 add-claude-key-to-keychain.py

The key is typed blind and never echoed, never written to a file and never in shell
history. Run it again to replace the stored key.
"""
import getpass
import sys

try:
    import keyring
except ImportError:
    sys.exit("keyring is missing. Install with: /usr/bin/python3 -m pip install --user keyring")

key = getpass.getpass("Anthropic API key (not shown as you type): ").strip()
if not key:
    sys.exit("nothing entered, keychain unchanged")

keyring.set_password("Anthropic", "ClaudeAPI", key)
print("Stored. image-subject.py will read it from the keychain.")
