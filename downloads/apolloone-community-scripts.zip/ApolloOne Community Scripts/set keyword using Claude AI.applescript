# Set keywords using Claude AI
#
# Sends every selected photo in ApolloOne to Claude and adds the answer to its keywords.
#
# Setup, once:
#   /usr/bin/python3 -m pip install --user anthropic keyring
#   /usr/bin/python3 add-claude-key-to-keychain.py
#   copy image-subject.py to ~/Library/Application Support/ApolloOne Scripts/
#   (not into the Scripts folder: the Scripts menu lists every file there, and
#   image-subject.py is a helper this script calls, not something to pick from the menu)
#
# The photos leave this Mac: each one is resized to 1024 pixels and sent to Anthropic's
# API on your own API key and billing. ApolloOne's own AI Keywords does not do this; it
# runs on Apple's Private Cloud Compute.

use scripting additions

set scriptLocation to (POSIX path of (path to home folder)) & "Library/Application Support/ApolloOne Scripts/image-subject.py"

# Sonnet is the default. Opus is Anthropic's more capable model, for harder look-alikes, at
# about three times the cost per photo. Haiku was dropped: for species it was wrong or too general.
set modelOptions to {"claude-sonnet-5", "claude-opus-5"}
set modelUsed to choose from list modelOptions with prompt "Select Claude AI model to use (Opus: more capable, about 3x the cost)" default items {"claude-sonnet-5"}
if modelUsed is false then error number -128
set modelUsed to item 1 of modelUsed

set languageOptions to {"Chinese, Simplified", "Chinese Traditional", "Dutch", "English", "French", "German", "Italian", "Japanese", "Korean", "Polish", "Spanish"}
set languageUsed to choose from list languageOptions with prompt "Select language for keywords" default items {"English"}
if languageUsed is false then error number -128
set languageUsed to item 1 of languageUsed

# Everything Claude answers becomes keywords (split at commas), so the prompt must ask for
# the name and nothing else. Asking for alternatives, as ApolloOne's own prompt does, would
# write the look-alike species into the keywords as if they were the answer: ApolloOne shows
# its alternatives in a picker for review, and a script has no such step.
set defaultPrompt to "You are keywording a photographer's catalog. Identify the animal in the photo and reply with its species' common name only. Prefer one precise term over three vague ones. No other text, no alternatives, no explanation."

set promptDialog to display dialog "Prompt for Claude AI : " default answer defaultPrompt with icon note buttons {"Continue", "Cancel"} default button "Continue"
if (button returned of promptDialog) is equal to "Cancel" then error number -128
set promptForAI to (text returned of promptDialog)

display notification "Processing of files is started"

# Write the prompt for Claude to a file, for lengthy prompts
# set promptFolder to choose folder with prompt "Select the location to write the prompt file :"

# One private directory for the run, mode 700, removed at the end. A fixed name in /tmp
# would collide between two runs and be readable by every account on the Mac.
set workDir to do shell script "/usr/bin/mktemp -d -t apolloone-claude"

set promptFile to workDir & "/claude_prompt.txt"
try
	set fileDescriptor to open for access promptFile with write permission
	set eof of fileDescriptor to 0
	write promptForAI to fileDescriptor starting at eof as «class utf8»
	close access fileDescriptor
on error writeError
	# `myFile` was undefined here, and an inner try with no `on error` swallowed the
	# failure - so a prompt file that could not be written let the whole run continue
	# and every photo failed with Python's "no such prompt file" instead.
	try
		close access fileDescriptor
	end try
	do shell script "/bin/rm -rf " & quoted form of workDir
	error "Could not write the prompt file: " & writeError
end try

tell application "ApolloOne"
	set selectedItems to selection
end tell
set totalItems to the number of items in selectedItems
if totalItems is 0 then
	display notification "Select some photos first" with title "Set keywords using Claude AI"
	return
end if

set resizedFile to workDir & "/resized.jpg"

set doneCount to 0
set failedCount to 0
set firstError to ""

# Two progress indicators on purpose. AppleScript's own is shown by Script Editor and
# carries the text, but NOTHING shows it when the script is run from the menu bar's
# Scripts menu. ApolloOne's own bar - the one above the status bar - is visible wherever
# ApolloOne is. Requires ApolloOne 5.0.0 or later, Max Edition.
set progress total steps to totalItems
set progress completed steps to 0
set progress description to "Determining the subjects in the photos..."
tell application "ApolloOne" to show progress bar steps totalItems

try
	repeat with itemIndex from 1 to totalItems
		set thisVariant to item itemIndex of selectedItems
		set progress additional description to "Processing " & itemIndex & " of " & totalItems
		try
			tell application "ApolloOne" to set filePath to file path of thisVariant
			# quoted form of, not hand-written quotes: a path or a prompt containing an
			# apostrophe (Mum's photos, the bird's name) ends the shell string early.
			do shell script "/usr/bin/sips -s format jpeg " & quoted form of filePath & " -Z 1024 --out " & quoted form of resizedFile
			set answer to do shell script "/usr/bin/python3 " & quoted form of scriptLocation & " " & quoted form of languageUsed & " " & quoted form of resizedFile & " " & quoted form of promptFile & " " & quoted form of modelUsed
			set newKeywords to keywordListFrom(answer)
			if newKeywords is not {} then
				# The + prefix ADDS through ApolloOne's merge grammar. A bare list would
				# replace every keyword the photo already has.
				tell application "ApolloOne" to set keywords of thisVariant to newKeywords
				set doneCount to doneCount + 1
			else
				set failedCount to failedCount + 1
			end if
		on error errorMessage
			# One photo failing (network, quota, a refusal) must not end the run.
			set failedCount to failedCount + 1
			if firstError is "" then set firstError to errorMessage
		end try
		# Both bars move AFTER the photo, so they count finished work and do reach the end.
		set progress completed steps to itemIndex
		tell application "ApolloOne" to set progress bar step to itemIndex
	end repeat
on error errorMessage number errorNumber
	do shell script "/bin/rm -rf " & quoted form of workDir
	tell application "ApolloOne" to hide progress bar
	set progress total steps to 0
	set progress completed steps to 0
	set progress description to ""
	set progress additional description to ""
	error errorMessage number errorNumber
end try

do shell script "/bin/rm -rf " & quoted form of workDir
tell application "ApolloOne" to hide progress bar
set progress total steps to 0
set progress completed steps to 0
set progress description to ""
set progress additional description to ""

if failedCount is 0 then
	display notification (doneCount as text) & " of " & totalItems & " photos keyworded" with title "Set keywords using Claude AI"
else
	display notification (doneCount as text) & " done, " & failedCount & " failed. " & firstError with title "Set keywords using Claude AI"
end if

# Claude's answer as a keyword list, each term prefixed + so it is added, not substituted.
# A comma-separated answer becomes several keywords; a one-word answer stays one.
on keywordListFrom(answer)
	set answer to trimmed(answer)
	if answer is "" then return {}
	set savedDelimiters to AppleScript's text item delimiters
	set AppleScript's text item delimiters to ","
	set rawTerms to text items of answer
	set AppleScript's text item delimiters to savedDelimiters
	set keywordTerms to {}
	repeat with rawTerm in rawTerms
		set term to trimmed(rawTerm as text)
		if term is not "" then set end of keywordTerms to "+" & term
	end repeat
	return keywordTerms
end keywordListFrom

on trimmed(someText)
	set whiteSpace to {space, tab, return, linefeed}
	repeat while someText is not "" and (character 1 of someText) is in whiteSpace
		if (count of someText) is 1 then return ""
		set someText to text 2 thru -1 of someText
	end repeat
	repeat while someText is not "" and (character -1 of someText) is in whiteSpace
		if (count of someText) is 1 then return ""
		set someText to text 1 thru -2 of someText
	end repeat
	return someText
end trimmed
