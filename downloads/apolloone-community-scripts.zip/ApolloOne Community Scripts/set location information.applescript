use scripting additions

set cityListFile to choose file with prompt "Select the file containing the list of places and states/province :"
#set stateListFile to choose file with prompt "Selecteer de lijst met provincies:"

set delimiterOptions to {",", ";"}
set delimiterUsed to choose from list delimiterOptions with prompt "Select city | state delimiter" default items {";"}
set tempTID to text item delimiters -- save current delimiters
set text item delimiters to delimiterUsed

set progress completed steps to 0
set progress description to "Processing files..."
set progress additional description to "Preparing processing."


set progressCompletedItems to 1
set progress completed steps to 1
set progress description to "Reading the file"

set listOfCities to {}
set cities to paragraphs of (read file cityListFile as «class utf8»)
set totalItems to count of cities
set progress total steps to totalItems
repeat with nextLine in cities
	set progress additional description to "Processing " & progressCompletedItems & " of " & totalItems
	set progress completed steps to progressCompletedItems
	if length of nextLine is greater than 0 then
		copy nextLine to the end of listOfCities
	end if
	set progressCompletedItems to progressCompletedItems + 1
end repeat

set locationDialog to display dialog "What is the location for these photos ?" default answer "" with icon note buttons {"Continue", "Cancel"} default button "Continue"
if (button returned of locationDialog) is equal to "Cancel" then
	tell me to error "Processing cancelled"
end if
set locationIPTC to (text returned of locationDialog)

set citySelected to choose from list listOfCities with prompt "Select the city closest to the location"
if citySelected is false then
	tell me to error "Processing cancelled"
end if

set citySelected to citySelected as Unicode text
set cityInfo to text items of citySelected
set cityIPTC to item 1 of cityInfo
set stateIPTC to item 2 of cityInfo

set countryDialog to display dialog "What is the country ?" default answer "" with icon note buttons {"Continue", "Cancel"} default button "Continue"
if (button returned of countryDialog) is equal to "Cancel" then
	tell me to error "Processing cancelled"
end if
set countryIPTC to (text returned of countryDialog)

set countryCodeDialog to display dialog "What is the country code (ISO 3166, e.g. NLD, USA) ?" default answer "" with icon note buttons {"Continue", "Cancel"} default button "Continue"
if (button returned of countryCodeDialog) is equal to "Cancel" then
	tell me to error "Processing cancelled"
end if
set countryCodeIPTC to (text returned of countryCodeDialog)

tell application "ApolloOne"
	set totalItems to the number of items in (get selection)
	set selectedItems to selection
end tell

# Two progress indicators on purpose. AppleScript's own is shown by Script Editor and
# carries the text, but NOTHING shows it when the script is run from the menu bar's
# Scripts menu. ApolloOne's own bar - the one above the status bar - is visible wherever
# ApolloOne is. Requires ApolloOne 5.0.0 or later, Max Edition.
set progress total steps to totalItems
set progress completed steps to 0
set progress description to "Processing files..."
set progress additional description to "Preparing processing."
tell application "ApolloOne" to show progress bar steps totalItems

set progressCompletedItems to 1
set progress completed steps to 1
set progress description to "Setting the IPTC/XMP location information..."
tell application "ApolloOne" to set progress bar step to 1

repeat with thisVariant in selectedItems
	set progress additional description to "Processing " & progressCompletedItems & " of " & totalItems
	
	tell application "ApolloOne"
		tell thisVariant to set its location to locationIPTC
		tell thisVariant to set its city to cityIPTC
		tell thisVariant to set its state to stateIPTC
		tell thisVariant to set its country to countryIPTC
		tell thisVariant to set its country code to countryCodeIPTC
		set progress bar step to progressCompletedItems
	end tell
	set progress completed steps to progressCompletedItems
	set progressCompletedItems to progressCompletedItems + 1
end repeat

tell application "ApolloOne" to hide progress bar
set progress total steps to 0
set progress completed steps to 0
set progress description to ""
set progress additional description to ""
display notification "Information is copied to the location fields" with title "Set location information"
