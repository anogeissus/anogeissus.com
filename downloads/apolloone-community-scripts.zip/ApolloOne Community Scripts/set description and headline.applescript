use scripting additions

# The words that join title, location and city in the headline and description.
# In Dutch, for example: " bij " and " in de buurt van ".
property atWord : " at "
property nearWord : " near "

tell application "ApolloOne"
	set totalItems to the number of items in (get selection)
	set selectedItems to selection
end tell

# Two progress indicators on purpose. AppleScript's own is shown by Script Editor and
# carries the text, but NOTHING shows it when the script is run from the menu bar's
# Scripts menu. ApolloOne's own bar - the one above the status bar - is visible wherever
# ApolloOne is. Requires ApolloOne 5.0.0 or later, Max Edition.
set progress total steps to totalItems
set progress completed steps to 0
set progress description to "Processing selection..."
set progress additional description to "Preparing...."
tell application "ApolloOne" to show progress bar steps totalItems

set progressCompletedItems to 1
set progress completed steps to 1
set progress description to "Generate IPTC/XMP Description and Headline for selected files..."

repeat with thisVariant in selectedItems
	set progress additional description to "Processing item " & progressCompletedItems & " of " & totalItems
	set progress completed steps to progressCompletedItems
	tell application "ApolloOne"
		set imageLocation to location of thisVariant
		set imageCity to city of thisVariant
		set imageTitle to title of thisVariant
		set imageHeadline to imageTitle & atWord & imageLocation
		set imageDescription to imageTitle & atWord & imageLocation & nearWord & imageCity
		tell thisVariant to set its headline to imageHeadline
		tell thisVariant to set its description to imageDescription
		set progress bar step to progressCompletedItems
	end tell
	set progressCompletedItems to progressCompletedItems + 1
end repeat

tell application "ApolloOne" to hide progress bar
display notification "Information is generated and copied to the headline and description" with title "Set description and headline"
