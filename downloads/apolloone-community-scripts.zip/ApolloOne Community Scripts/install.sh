#!/bin/bash
# Installs the ApolloOne community scripts.
#
# Run it from Terminal: type "bash " (with the space), drag this file into the Terminal
# window, and press Return.
#
#   - copies the five scripts to ~/Library/Scripts/ApolloOne/ (replacing older copies)
#   - optionally sets up the Claude AI keyword script: installs the two Python packages it
#     needs, copies image-subject.py to ~/Library/Application Support/ApolloOne Scripts/,
#     and stores your Anthropic API key in the login keychain

set -e

here="$(cd "$(dirname "$0")" && pwd)"
scripts_dir="$HOME/Library/Scripts/ApolloOne"
helper_dir="$HOME/Library/Application Support/ApolloOne Scripts"

echo "Installing the ApolloOne community scripts"
echo

mkdir -p "$scripts_dir"
count=0
for f in "$here"/*.applescript; do
	[ -e "$f" ] || continue
	cp "$f" "$scripts_dir/"
	count=$((count + 1))
done
if [ "$count" -eq 0 ]; then
	echo "No .applescript files next to install.sh. Run it from the unzipped folder."
	exit 1
fi
echo "Copied $count scripts to $scripts_dir"
echo

read -r -p "Also set up the Claude AI keyword script? It needs your own paid Anthropic API key. [Y/n] " answer
case "$answer" in
	[nN]*)
		echo "Skipped. Run install.sh again any time to set it up."
		;;
	*)
		# /usr/bin/python3 comes with Apple's Command Line Tools (or Xcode).
		if ! /usr/bin/xcode-select -p >/dev/null 2>&1; then
			echo
			echo "The Claude script needs Python, which comes with Apple's Command Line Tools."
			echo "macOS will now offer to install them. When that has finished, run install.sh again."
			/usr/bin/xcode-select --install 2>/dev/null || true
			exit 1
		fi

		mkdir -p "$helper_dir"
		cp "$here/image-subject.py" "$helper_dir/"
		echo "Copied image-subject.py to $helper_dir"

		echo "Installing the Python packages (anthropic, keyring)..."
		/usr/bin/python3 -m pip install --user --quiet --disable-pip-version-check --no-warn-script-location anthropic keyring
		echo "Done."
		echo

		store_key=yes
		if /usr/bin/python3 -c 'import keyring, sys; sys.exit(0 if keyring.get_password("Anthropic", "ClaudeAPI") else 1)' 2>/dev/null; then
			read -r -p "An API key is already stored in your keychain. Replace it? [y/N] " replace
			case "$replace" in
				[yY]*) ;;
				*) store_key=no; echo "Kept the stored key." ;;
			esac
		fi

		if [ "$store_key" = yes ]; then
			read -r -s -p "Paste your Anthropic API key (it is not shown), then press Return: " key
			echo
			if [ -z "$key" ]; then
				echo "No key entered. Run install.sh again to add it."
			else
				case "$key" in
					sk-ant-api*) ;;
					*) echo "Note: Anthropic API keys start with sk-ant-api. Storing it anyway." ;;
				esac
				# printf is a shell builtin, so the key never appears in the process list.
				printf '%s' "$key" | /usr/bin/python3 -c 'import sys, keyring; keyring.set_password("Anthropic", "ClaudeAPI", sys.stdin.read().strip())'
				echo "Stored the key in your login keychain."
			fi
			unset key
		fi
		;;
esac

echo
echo "Last step, if you have not done it before: open Script Editor, choose"
echo "Script Editor > Settings > General, and select \"Show Script menu in menu bar\"."
echo "The scripts are then in the scroll menu in the menu bar, under ApolloOne."
