# This script sets the title of each selected photo to the last keyword in the 'subject' field.
# It also sets the 'headline' and 'description' fields by using the 'title', 'location' and 'city' fields.
# The 'comment' field is used to store a version of the generated title with any spaces replaced by an underscore.
# The {comment} variable can then be used in the batch rename to generate filenames without a space,
# using code replacement in the Metadata templates.
# Photos without keywords are skipped.

use scripting additions

# The words that join title, location and city in the headline and description.
# In Dutch, for example: " bij " and " in de buurt van ".
property atWord : " at "
property nearWord : " near "

on findAndReplaceInText(theText, theSearchString, theReplacementString)
	set AppleScript's text item delimiters to theSearchString
	set theTextItems to every text item of theText
	set AppleScript's text item delimiters to theReplacementString
	set theText to theTextItems as string
	set AppleScript's text item delimiters to ""
	return theText
end findAndReplaceInText

tell application "ApolloOne"
	set totalItems to the number of items in (get selection)
	set selectedItems to selection
end tell

# Two progress indicators on purpose. AppleScript's own is shown by Script Editor and
# carries the text, but NOTHING shows it when the script is run from the menu bar's
# Scripts menu. ApolloOne's own bar - the one above the status bar - is visible wherever
# ApolloOne is. Requires ApolloOne 5.0.0 or later, Max Edition.
set progress total steps to totalItems
set progress completed steps to 0
set progress description to "Processing selection..."
set progress additional description to "Preparing...."
tell application "ApolloOne" to show progress bar steps totalItems

set progressCompletedItems to 1
set progress completed steps to 1
set progress description to "Generate IPTC/XMP Title, Description and Headline for selected files..."

set skippedCount to 0

repeat with thisVariant in selectedItems
	set progress additional description to "Processing item " & progressCompletedItems & " of " & totalItems
	set progress completed steps to progressCompletedItems
	tell application "ApolloOne"
		set keywordItems to keywords of thisVariant
		set numberOfKeywords to number of items in keywordItems
		if numberOfKeywords is 0 then
			# No keyword to take the title from. "item 0" would stop the whole run and
			# leave the progress bar on screen, so leave this photo alone and carry on.
			set skippedCount to skippedCount + 1
		else
			set lastKeyword to item numberOfKeywords of keywordItems
			set imageLocation to location of thisVariant
			set imageTitle to lastKeyword
			set imageCity to city of thisVariant
			set imageHeadline to imageTitle & atWord & imageLocation
			set imageDescription to imageTitle & atWord & imageLocation & nearWord & imageCity
			tell thisVariant to set its title to imageTitle
			tell thisVariant to set its headline to imageHeadline
			tell thisVariant to set its description to imageDescription
			tell thisVariant to set its comment to my findAndReplaceInText(imageTitle, " ", "_")
		end if
		set progress bar step to progressCompletedItems
	end tell
	set progressCompletedItems to progressCompletedItems + 1
end repeat

tell application "ApolloOne" to hide progress bar
if skippedCount is 0 then
	display notification "Information is generated and copied to the title, headline and description" with title "Set title, headline and description"
else
	display notification "Information is generated and copied to the title, headline and description. " & skippedCount & " photos without keywords were skipped." with title "Set title, headline and description"
end if
