#!/usr/bin/env python3
"""Ask Claude about one image and print the answer.

    image-subject.py <language> <image path> <prompt> [model]

The API key is read from the keychain (service "Anthropic", account "ClaudeAPI");
add-claude-key-to-keychain.py puts it there. Errors go to stderr and exit 1, so the
calling script can trap a single failure and carry on with the rest of the selection.

Model: claude-sonnet-5 by default; claude-opus-5 is the more capable choice for hard
look-alikes, at about three times the cost per photo. Measured on seven birds, both named
all seven correctly. Haiku is not offered: on the same seven, claude-haiku-4-5 agreed with
Sonnet on none, answering at family level - "Geese" where Sonnet said "Barnacle goose".
"""
import base64
import sys
from pathlib import Path

DEFAULT_MODEL = "claude-sonnet-5"
MARKDOWN = "*_`\"'\u201c\u201d\u2018\u2019"

MEDIA_TYPES = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".webp": "image/webp",
}


def fail(message):
    print(message, file=sys.stderr)
    sys.exit(1)


def clean(answer):
    """Strip the markdown a model sometimes wraps a short answer in.

    Measured on seven bird photos: Sonnet 5 returned "**Australian King Parrot**" for one photo
    of seven, and Haiku 4.5 returned "# Crimson Rosella". Written through unchanged, the
    asterisks and the hash end up inside the keyword. Several lines become several terms,
    comma separated, which the AppleScript then splits into separate keywords.
    """
    terms = []
    for line in answer.replace("\r", "\n").split("\n"):
        for part in line.split(","):
            # Strip until nothing changes: "Kookaburra**." needs the period off before the
            # asterisks are at the end to be stripped at all.
            term, previous = part.strip(), None
            while term != previous:
                previous = term
                term = term.strip().strip(MARKDOWN).strip()
                while term[:1] in {"#", "-", "\u2022"}:
                    term = term[1:].strip()
                if term.endswith(".") and term.count(".") == 1:
                    term = term[:-1].strip()
            if term:
                terms.append(term)
    return ", ".join(terms)


def analyze_local_image(client, model, image_path, question):
    image_bytes = Path(image_path).read_bytes()
    media_type = MEDIA_TYPES.get(Path(image_path).suffix.lower(), "image/jpeg")
    response = client.messages.create(
        model=model,
        max_tokens=2048,
        messages=[{
            "role": "user",
            "content": [
                {"type": "image", "source": {
                    "type": "base64",
                    "media_type": media_type,
                    "data": base64.standard_b64encode(image_bytes).decode("utf-8"),
                }},
                {"type": "text", "text": question},
            ],
        }],
    )
    return clean("".join(block.text for block in response.content if block.type == "text"))


def main():
    if len(sys.argv) < 4:
        fail("usage: image-subject.py <language> <image path> <prompt_path> [model]")
    language, image_path, prompt_path = sys.argv[1], sys.argv[2], sys.argv[3]
    model = sys.argv[4] if len(sys.argv) > 4 else DEFAULT_MODEL

    try:
        import anthropic
        import keyring
    except ImportError as exc:
        fail(f"{exc}. Install with: /usr/bin/python3 -m pip install --user anthropic keyring")

    if not Path(image_path).is_file():
        fail(f"no such image: {image_path}")

    if not Path(prompt_path).is_file():
        fail(f"no such prompt file: {prompt_path}")
    
    question = Path(prompt_path).read_text()

    api_key = keyring.get_password("Anthropic", "ClaudeAPI")
    if not api_key:
        fail("no API key in the keychain. Run add-claude-key-to-keychain.py first.")

    try:
        answer = analyze_local_image(
            anthropic.Anthropic(api_key=api_key), model,
            image_path, f"{question} return answer in {language}")
    except Exception as exc:                      # network, quota, bad key, refusal
        fail(f"{type(exc).__name__}: {exc}")

    if not answer:
        fail("empty answer")
    print(answer)


if __name__ == "__main__":
    main()
