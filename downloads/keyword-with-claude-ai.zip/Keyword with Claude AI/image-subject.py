#!/usr/bin/env python3
"""Ask Claude about one image and print the answer.

    image-subject.py <language> <image path> <prompt> [model]

When the image has a GPS position, the prompt also says where it was taken, rounded to
about 10 km: look-alike species often differ in range, and it is the one location a camera
records by itself.

The API key is read from the keychain (service "Anthropic", account "ClaudeAPI");
add-claude-key-to-keychain.py puts it there. Errors go to stderr and exit 1, so the
calling script can trap a single failure and carry on with the rest of the selection.

Model: claude-sonnet-5 by default; claude-opus-5 is the more capable choice for hard
look-alikes, at about three times the cost per photo. Measured on seven birds, both named
all seven correctly. Haiku is not offered: on the same seven, claude-haiku-4-5 agreed with
Sonnet on none, answering at family level - "Geese" where Sonnet said "Barnacle goose".
"""
import base64
import struct
import sys
from pathlib import Path

DEFAULT_MODEL = "claude-sonnet-5"
MARKDOWN = "*_`\"'\u201c\u201d\u2018\u2019"

MEDIA_TYPES = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".webp": "image/webp",
}


def fail(message):
    print(message, file=sys.stderr)
    sys.exit(1)


def clean(answer):
    """Strip the markdown a model sometimes wraps a short answer in.

    Measured on seven bird photos: Sonnet 5 returned "**Australian King Parrot**" for one photo
    of seven, and Haiku 4.5 returned "# Crimson Rosella". Written through unchanged, the
    asterisks and the hash end up inside the keyword. Several lines become several terms,
    comma separated, which the AppleScript then splits into separate keywords.
    """
    terms = []
    for line in answer.replace("\r", "\n").split("\n"):
        for part in line.split(","):
            # Strip until nothing changes: "Kookaburra**." needs the period off before the
            # asterisks are at the end to be stripped at all.
            term, previous = part.strip(), None
            while term != previous:
                previous = term
                term = term.strip().strip(MARKDOWN).strip()
                while term[:1] in {"#", "-", "\u2022"}:
                    term = term[1:].strip()
                if term.endswith(".") and term.count(".") == 1:
                    term = term[:-1].strip()
            if term:
                terms.append(term)
    return ", ".join(terms)


def exif_block(jpeg):
    """The TIFF block inside a JPEG's EXIF segment, or None."""
    if jpeg[:2] != b"\xff\xd8":
        return None
    pos = 2
    while jpeg[pos] == 0xFF and jpeg[pos + 1] != 0xDA:    # the segments before the image data
        length = int.from_bytes(jpeg[pos + 2:pos + 4], "big")
        if jpeg[pos + 1] == 0xE1 and jpeg[pos + 4:pos + 10] == b"Exif\0\0":
            return jpeg[pos + 10:pos + 2 + length]
        pos += 2 + length
    return None


def gps_text(jpeg):
    """The GPS position in a JPEG's EXIF as "33.9° S, 151.2° E", or None.

    Rounded to a tenth of a degree, about 10 km, which is plenty for a species' range. sips
    keeps the EXIF when it makes the 1024-pixel copy, RAW files included. 0° 0° is what some
    cameras write without a fix, so it counts as none, as does anything unreadable: the photo
    then goes without a position.
    """
    try:
        tiff = exif_block(jpeg)
        if not tiff:
            return None
        order = {b"II": "<", b"MM": ">"}[tiff[:2]]

        def number(fmt, at):
            return struct.unpack_from(order + fmt, tiff, at)[0]

        def entries(ifd):       # tag -> offset of the entry's 4-byte value field
            return {number("H", ifd + 2 + 12 * i): ifd + 10 + 12 * i for i in range(number("H", ifd))}

        def degrees(field):     # three rationals: degrees, minutes, seconds
            n = struct.unpack_from(order + "6I", tiff, number("I", field))
            return n[0] / n[1] + n[2] / n[3] / 60 + n[4] / n[5] / 3600

        gps = entries(number("I", entries(number("I", 4))[0x8825]))
        lat, lon = degrees(gps[2]), degrees(gps[4])
        lat_ref, lon_ref = chr(tiff[gps[1]]), chr(tiff[gps[3]])
    except (IndexError, KeyError, ValueError, struct.error, ZeroDivisionError):
        return None
    if lat_ref not in "NS" or lon_ref not in "EW" or lat > 90 or lon > 180 or lat == lon == 0:
        return None
    return f"{lat:.1f}° {lat_ref}, {lon:.1f}° {lon_ref}"


def analyze_local_image(client, model, image_path, question):
    image_bytes = Path(image_path).read_bytes()
    media_type = MEDIA_TYPES.get(Path(image_path).suffix.lower(), "image/jpeg")
    response = client.messages.create(
        model=model,
        max_tokens=2048,
        messages=[{
            "role": "user",
            "content": [
                {"type": "image", "source": {
                    "type": "base64",
                    "media_type": media_type,
                    "data": base64.standard_b64encode(image_bytes).decode("utf-8"),
                }},
                {"type": "text", "text": question},
            ],
        }],
    )
    return clean("".join(block.text for block in response.content if block.type == "text"))


def main():
    if len(sys.argv) < 4:
        fail("usage: image-subject.py <language> <image path> <prompt_path> [model]")
    language, image_path, prompt_path = sys.argv[1], sys.argv[2], sys.argv[3]
    model = sys.argv[4] if len(sys.argv) > 4 else DEFAULT_MODEL

    try:
        import anthropic
        import keyring
    except ImportError as exc:
        fail(f"{exc}. Install with: /usr/bin/python3 -m pip install --user anthropic keyring")

    if not Path(image_path).is_file():
        fail(f"no such image: {image_path}")

    if not Path(prompt_path).is_file():
        fail(f"no such prompt file: {prompt_path}")
    
    question = Path(prompt_path).read_text()
    position = gps_text(Path(image_path).read_bytes())
    if position:
        question += f"\nThe photo was taken near {position}."

    api_key = keyring.get_password("Anthropic", "ClaudeAPI")
    if not api_key:
        fail("no API key in the keychain. Run add-claude-key-to-keychain.py first.")

    try:
        answer = analyze_local_image(
            anthropic.Anthropic(api_key=api_key), model,
            image_path, f"{question}\nReturn the answer in {language}.")
    except Exception as exc:                      # network, quota, bad key, refusal
        fail(f"{type(exc).__name__}: {exc}")

    if not answer:
        fail("empty answer")
    print(answer)


if __name__ == "__main__":
    main()
